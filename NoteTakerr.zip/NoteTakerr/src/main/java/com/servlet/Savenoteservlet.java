package com.servlet;

import java.io.IOException;

import java.io.PrintWriter;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.entities.Note;
import com.helper.FactoryProvider;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class Savenoteservlet extends HttpServlet {

	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
	
		try {
			
			String t = req.getParameter("title");
			String c = req.getParameter("content");
			
			Note n=new Note(t,c,new Date());
			System.out.print(n.getId());
			
			//hibernate
			Session session = FactoryProvider.getFactory().openSession();
			
			Transaction tx = session.beginTransaction();
			
			session.save(n);
			
			tx.commit();
			session.close();
//			FactoryProvider.closeFactory();
			
			res.setContentType("text/html");
			PrintWriter out=res.getWriter();
			out.println("<h1 style='text-align:center;'>note Added Sucessfully</h1>");
			out.println("<h1 style='text-align:center;'><a href='all_notes.jsp'>View All Notes</a></h1>");
			
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
