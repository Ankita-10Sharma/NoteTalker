package com.servlet;

import java.io.IOException;
import java.util.Date;

import com.entities.Note;
import com.helper.FactoryProvider;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.hibernate.*;



public class updateservlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			String t=request.getParameter("title");
			String content=request.getParameter("content");
			
			Session s=FactoryProvider.getFactory().openSession();
			Transaction tx = s.beginTransaction();
			int ni=Integer.parseInt(request.getParameter("noteid").trim());
			Note note = s.get(Note.class, ni);
			note.setTitle(t);
			note.setContent(content);
			Date d=new Date();
			tx.commit();
			s.close();
			response.sendRedirect("all_notes.jsp?date="+d);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
