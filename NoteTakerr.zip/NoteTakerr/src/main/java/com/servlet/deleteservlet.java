package com.servlet;

import java.io.IOException;

import com.entities.Note;
import com.helper.FactoryProvider;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class deleteservlet extends HttpServlet {
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		try {
			int ni=Integer.parseInt(req.getParameter("note_id").trim());
			Session s=FactoryProvider.getFactory().openSession();
			
			Note note = (Note)s.get(Note.class,ni);
			Transaction tx = s.beginTransaction();
			s.delete(note);
			tx.commit();
			s.close();
			res.sendRedirect("all_notes.jsp");
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
